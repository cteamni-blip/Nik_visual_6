package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.render.GuiDraw;
import com.nik.visuals.client.slot.CooldownQuery;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;

@Environment(EnvType.CLIENT)
public class InventoryHudRenderer {
    public static final int CELL = 18;
    public static final int COLS = 9;
    public static final int ROWS = 3;
    private int lastX;
    private int lastY;
    private int lastW;
    private int lastH;

    public int getLastX() {
        return this.lastX;
    }

    public int getLastY() {
        return this.lastY;
    }

    public int getLastW() {
        return this.lastW;
    }

    public int getLastH() {
        return this.lastH;
    }

    public float getScale() {
        return Math.max(0.5f, Math.min(1.8f, ModConfig.inventoryHudScale));
    }

    public void render(DrawContext g, float pt) {
        if (!ModConfig.inventoryHud && !ModConfig.layoutEdit) {
            return;
        }
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null) {
            return;
        }
        if (mc.currentScreen != null && !ModConfig.layoutEdit) {
            return;
        }
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        float scale = this.getScale();
        int x = (int)(ModConfig.inventoryHudX * (float)sw);
        int y = (int)(ModConfig.inventoryHudY * (float)sh);
        int gridW = 166;
        int gridH = 58;
        this.lastX = x;
        this.lastY = y;
        this.lastW = (int)((float)gridW * scale);
        this.lastH = (int)((float)gridH * scale);
        g.getMatrices().pushMatrix();
        g.getMatrices().translate((float)x, (float)y);
        g.getMatrices().scale(scale);
        GuiDraw.fillRounded(g, -2);
        GuiDraw.fillRounded(g, 0, 0, gridW, gridH, 5, -871626220);
        for (int row = 0; row < 3; ++row) {
            for (int col = 0; col < 9; ++col) {
                String text;
                float[] cd;
                int slot = 9 + row * 9 + col;
                int sx = 2 + col * 18;
                int sy = 2 + row * 18;
                g.fill(sx, sy, sx + 16, sy + 16, 1143085104);
                ItemStack stack = p.getInventory().getStack(slot);
                if (stack.isEmpty()) continue;
                g.drawItem(stack, sx, sy);
                g.drawStackOverlay(mc.textRenderer, stack, sx, sy);
                if (!ModConfig.slotTimer || (cd = CooldownQuery.query(p, stack, pt)) == null) continue;
                float progress = cd[0];
                float seconds = cd[1];
                if (ModConfig.slotTimerOverlay) {
                    int h = Math.max(1, (int)(16.0f * progress));
                    g.fill(sx, sy + (16 - h), sx + 16, sy + 16, -1728053248);
                }
                String string = text = seconds >= 10.0f ? String.valueOf((int)Math.ceil(seconds)) : String.format("%.1f", Float.valueOf(seconds));
                int color = progress <= 0.33f ? -11141291 : (progress <= 0.66f ? -171 : -43691);
                float ts = 0.65f;
                g.getMatrices().pushMatrix();
                g.getMatrices().translate((float)(sx + 1), (float)(sy + 1));
                g.getMatrices().scale(ts);
                g.drawText(mc.textRenderer, text);
                g.drawText(mc.textRenderer, text, 0, 0, color, false);
                g.getMatrices().popMatrix();
            }
        }
        g.getMatrices().popMatrix();
    }
}

