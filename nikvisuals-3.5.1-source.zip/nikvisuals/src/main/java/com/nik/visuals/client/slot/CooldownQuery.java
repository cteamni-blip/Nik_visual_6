package com.nik.visuals.client.slot;

import com.nik.visuals.client.mixin.CooldownInstanceAccessor;
import com.nik.visuals.client.mixin.ItemCooldownsAccessor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.ItemCooldownManager;
import net.minecraft.item.ItemStack;

import java.util.Map;

@Environment(EnvType.CLIENT)
public final class CooldownQuery {
    private CooldownQuery() {}

    /** Remaining whole seconds, or -1 if none / <1s */
    public static int remainingSeconds(ClientPlayerEntity player, ItemStack stack, float partial) {
        if (player == null || stack == null || stack.isEmpty()) return -1;
        try {
            ItemCooldownManager mgr = player.getItemCooldownManager();
            float progress = mgr.getCooldownProgress(stack, partial);
            if (progress <= 0.001f) return -1;

            int tick = 0;
            int end = -1;
            int start = -1;
            if (mgr instanceof ItemCooldownsAccessor acc) {
                tick = acc.getTick();
                Map<?, ?> map = acc.getCooldowns();
                Object entry = null;
                // try item key
                entry = map.get(stack.getItem());
                if (entry == null) {
                    // try any value matching via progress-only fallback later
                    for (Map.Entry<?, ?> e : map.entrySet()) {
                        // single-item common case
                        if (map.size() == 1) { entry = e.getValue(); break; }
                    }
                }
                if (entry instanceof CooldownInstanceAccessor ce) {
                    end = ce.getEndTick();
                    try { start = ce.getStartTick(); } catch (Throwable ignored) {}
                } else if (entry != null) {
                    // reflection fallback on endTick field
                    try {
                        var f = entry.getClass().getDeclaredField("endTick");
                        f.setAccessible(true);
                        end = f.getInt(entry);
                        try {
                            var s = entry.getClass().getDeclaredField("startTick");
                            s.setAccessible(true);
                            start = s.getInt(entry);
                        } catch (Throwable ignored) {}
                    } catch (Throwable ignored) {}
                }
            }

            if (end > tick) {
                int remTicks = end - tick;
                // account for partial tick roughly
                int sec = (int) Math.ceil((remTicks - partial) / 20.0);
                return sec < 1 ? -1 : sec;
            }

            // Fallback: progress is remaining/total. If we know start/end use it; else estimate total from progress slope isn't available
            // Use progress * (end-start) if we have both, else progress * 20 for short CDs
            if (start >= 0 && end > start) {
                int total = end - start;
                int sec = (int) Math.ceil(progress * total / 20.0);
                return sec < 1 ? -1 : sec;
            }
            // last resort: many custom items use 20-100 tick CD; use progress*4 seconds max mid
            int sec = (int) Math.ceil(progress * 4.0);
            return sec < 1 ? -1 : Math.max(1, sec);
        } catch (Throwable t) {
            return -1;
        }
    }
}
