package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.theme.Anim;
import com.nik.visuals.client.theme.Style;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;

@Environment(EnvType.CLIENT)
public class TargetHUD {
    private LivingEntity target;
    private float appear;
    private float hpSmooth = 1f;
    private float flash;
    private int lastX, lastY, lastW = 140, lastH = 46;
    private int particleCooldown;

    public int getLastX() { return lastX; }
    public int getLastY() { return lastY; }
    public int getLastW() { return lastW; }
    public int getLastH() { return lastH; }
    public int scaledW() { return lastW; }
    public int scaledH() { return lastH; }

    public void tick(MinecraftClient mc) {
        LivingEntity next = null;
        if (mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.ENTITY) {
            Entity e = ((EntityHitResult) mc.crosshairTarget).getEntity();
            if (e instanceof LivingEntity le && le.isAlive()) next = le;
        }
        if (next != null) target = next;
        else if (target != null && (!target.isAlive() || (mc.player != null && target.squaredDistanceTo(mc.player) > 400))) {
            target = null;
        }

        boolean show = (ModConfig.targetHud && target != null) || ModConfig.layoutEdit;
        appear = Anim.approach(appear, show ? 1f : 0f, 0.16f);

        if (target != null) {
            float hp = realHealth(target) / Math.max(1f, realMax(target));
            float prev = hpSmooth;
            hpSmooth = Anim.approach(hpSmooth, hp, 0.12f);
            if (hpSmooth < prev - 0.02f) flash = 1f;

            if (ModConfig.targetParticles && mc.world != null && particleCooldown-- <= 0) {
                particleCooldown = 4;
                try {
                    double x = target.getX();
                    double y = target.getBodyY(0.5);
                    double z = target.getZ();
                    mc.world.addParticle(ParticleTypes.CRIT,
                            x + (mc.world.random.nextDouble() - 0.5) * 0.6,
                            y + (mc.world.random.nextDouble() - 0.5) * 0.6,
                            z + (mc.world.random.nextDouble() - 0.5) * 0.6,
                            0, 0.02, 0);
                } catch (Throwable ignored) {}
            }
        }
        flash = Anim.approach(flash, 0f, 0.1f);
    }

    public void render(DrawContext g, float pt) {
        if (appear < 0.02f) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        float a = Anim.easeOutCubic(appear);
        float scale = MathHelper.clamp(ModConfig.targetHudScale, 0.7f, 1.5f);

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int bw = 140, bh = 46;
        int x, y;
        if (ModConfig.targetHudX < 0) {
            x = sw / 2 - bw / 2;
            y = 14;
        } else {
            x = (int) (ModConfig.targetHudX * sw);
            y = (int) (ModConfig.targetHudY * sh);
        }
        lastX = x; lastY = y;
        lastW = (int) (bw * scale);
        lastH = (int) (bh * scale);

        g.getMatrices().pushMatrix();
        g.getMatrices().translate(x, y);
        g.getMatrices().scale(scale, scale);

        int panel = Style.alpha(Style.PANEL, a);
        int border = Style.alpha(Style.ACCENT_GLOW, a);
        GuiDraw.glassPanel(g, 0, 0, bw, bh, 12, panel, border);

        if (flash > 0.05f) {
            g.fill(2, 2, bw - 2, bh - 2, Style.solidAlpha(0xCC4444, (int) (45 * flash * a)));
        }

        String name = target != null ? target.getName().getString() : "Target";
        if (name.length() > 14) name = name.substring(0, 13) + "…";
        g.drawText(mc.textRenderer, name, 40, 9, Style.alpha(Style.TEXT, a), false);

        // head 24x24 box
        GuiDraw.fillRounded(g, 8, 10, 24, 24, 6, Style.alpha(Style.GLASS, a));
        g.fill(8, 10, 10, 34, Style.alpha(Style.ACCENT, a));

        boolean drewHead = false;
        try {
            Identifier skin = null;
            if (target instanceof AbstractClientPlayerEntity pl) {
                skin = pl.getSkinTextures().texture();
            } else if (target != null && mc.getNetworkHandler() != null) {
                PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(target.getUuid());
                if (entry != null) {
                    skin = entry.getSkinTextures().texture();
                }
            }
            if (skin != null) {
                // face 8,8 size 8 on 64 atlas -> draw 20x20
                g.drawTexture(RenderPipelines.GUI_TEXTURED, skin, 10, 12, 8f, 8f, 20, 20, 8, 8, 64, 64);
                // hat layer 40,8
                g.drawTexture(RenderPipelines.GUI_TEXTURED, skin, 10, 12, 40f, 8f, 20, 20, 8, 8, 64, 64);
                drewHead = true;
            }
        } catch (Throwable ignored) {}
        if (!drewHead) {
            GuiDraw.fillSoftCircle(g, 20, 22, 7, Style.alpha(Style.ACCENT_DIM, a));
        }

        float hp = target != null ? hpSmooth : 0.7f;
        int barColor = hp > 0.5f ? Style.OK : (hp > 0.25f ? Style.WARN : Style.DANGER);
        GuiDraw.hpBar(g, 40, 26, 90, 8, hp, Style.alpha(barColor, a), Style.alpha(Style.TRACK_OFF, a));

        String hpText = target == null ? "—/—" : (target.isInvisible() ? "?/?" : String.format("%.0f/%.0f", realHealth(target), realMax(target)));
        g.drawText(mc.textRenderer, hpText, 40, 36, Style.alpha(Style.TEXT_DIM, a), false);

        if (ModConfig.showDistance && target != null && mc.player != null) {
            String dist = String.format("%.1fm", mc.player.distanceTo(target));
            g.drawText(mc.textRenderer, dist, bw - 8 - mc.textRenderer.getWidth(dist), 9,
                    Style.alpha(Style.TEXT_DIM, a), false);
        }

        g.getMatrices().popMatrix();
    }

    /** Funtime/plugins often lie via absorption / attributes — combine sources */
    private static float realHealth(LivingEntity e) {
        try {
            float hp = e.getHealth();
            float abs = 0f;
            try { abs = e.getAbsorptionAmount(); } catch (Throwable ignored) {}
            // Some servers keep vanilla health at 20 while real is in absorption or vice versa
            float max = e.getMaxHealth();
            try {
                max = (float) e.getAttributeValue(net.minecraft.entity.attribute.EntityAttributes.MAX_HEALTH);
            } catch (Throwable ignored) {}
            // Prefer visible damage: if entity recently hurt, health is more trustworthy
            float total = hp + abs;
            if (total <= 0.01f) total = hp;
            // clamp crazy plugin values
            if (total > 1000) total = hp;
            return total;
        } catch (Throwable t) {
            return e.getHealth();
        }
    }

    private static float realMax(LivingEntity e) {
        try {
            float max = (float) e.getAttributeValue(net.minecraft.entity.attribute.EntityAttributes.MAX_HEALTH);
            if (max < 1f) max = e.getMaxHealth();
            return max;
        } catch (Throwable t) {
            return Math.max(1f, e.getMaxHealth());
        }
    }
}
