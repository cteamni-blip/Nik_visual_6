Nik Visuals 3.5

UI:
- Futuristic menu like reference (sidebar: Home/Visuals/Interface/Render/HUD/Settings)
- Right panel: empty preview + info (no image, no profiles)
- NV logo as mod icon

Fixes:
- Cooldown HUD movable + resizable in layout mode
- Cooldown seconds via endTick accessors
- Trajectory visible through blocks (depth test off)
- Target HP: health+absorption + ? when invisible (Funtime)
